package com.bvk.client;

import java.util.function.BiConsumer;
import java.util.function.Consumer;


public class ClientConsumer {
	public static void main(String args[]) {
		Consumer<Integer>consInt = (n)->System.out.println(n*n);
		consInt.accept(10);
		
		BiConsumer<Integer, Integer>bigConsume = (a,b)->System.out.println(a*b);
		bigConsume.accept(10,20);
	}

}
