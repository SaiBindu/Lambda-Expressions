package com.bvk.client;

import com.bvk.entity.LuckyNumber;

public class ClientLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LuckyNumber myNum;//declare an interface reference.
		//Using Java 7
		/*class getLucky implements LuckyNumber {
			public double getLuckyNumber(){
				return 21;
			}
		}*/
		myNum = /*new getLucky();*/new LuckyNumber(){
			public double getLuckyNumber(){
				return 21;
			}
		};
		
		System.out.println(myNum.getLuckyNumber());
		
		//Using Java 8
		myNum = () -> 21;
		
		System.out.println(myNum.getLuckyNumber());
	}
}