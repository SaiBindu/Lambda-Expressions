package com.bvk.client;

import com.bvk.entity.MyClass;
import com.bvk.entity.MyFunc;

public class ClientConstructorRef {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFunc myClassCons = MyClass::new;
		
		MyClass mc = myClassCons.func(100);
		
		System.out.println(mc.getValue());
	}
}