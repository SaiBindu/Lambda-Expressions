package com.bvk.client;

import java.util.function.Predicate;

public class ClientPredicate {
	 public static void main(String args[]) {
		 Predicate<Integer>isEven = (n)-> n%2 == 0;
		 System.out.println(isEven.test(2));
	 }
	

}
