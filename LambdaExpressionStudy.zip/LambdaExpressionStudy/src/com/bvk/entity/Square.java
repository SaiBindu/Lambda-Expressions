package com.bvk.entity;

public interface Square {
	int square();
}