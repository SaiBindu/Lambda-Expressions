package com.bvk.entity;

public interface CheckPrime {
	boolean isPrime(int number);
}