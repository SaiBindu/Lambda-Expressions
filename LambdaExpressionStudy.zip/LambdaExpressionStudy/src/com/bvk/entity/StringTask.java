package com.bvk.entity;

public interface StringTask {
	String func(String n);
}