package com.bvk.entity;

public class StringOperator {
	public String reverse(String n){
		String reversed = null;
		
		StringBuffer sbf = new StringBuffer(n);
		sbf.reverse();
		reversed = new String(sbf);
		
		return reversed;
	}
}