package com.bvk.entity;

public interface GenericReverse<T> {
	T reverse(T t);
}